<?php

Route::get('meeting', function() {
    return 'Meeting Setup';
});